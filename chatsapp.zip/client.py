import pika
import threading
import sys

EXCHANGE_NAME = "group_chat"

def listen_for_messages(channel, queue_name):
    def callback(ch, method, properties, body):
        print(f"[New Message]: {body.decode()}")
    
    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    channel.start_consuming()

def start_client(username):
    connection = pika.BlockingConnection(pika.ConnectionParameters("localhost"))
    channel = connection.channel()
    
    channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type="fanout")


    result = channel.queue_declare(queue="", exclusive=True)
    queue_name = result.method.queue

    channel.queue_bind(exchange=EXCHANGE_NAME, queue=queue_name)

    threading.Thread(target=listen_for_messages, args=(channel, queue_name), daemon=True).start()

    print(f"Welcome {username}! Type your messages below:")
    while True:
        try:
            message = input()
            if message.lower() == "exit":
                print("Exiting chat...")
                break
            full_message = f"{username}: {message}"
            
            channel.basic_publish(exchange="", routing_key="server_queue", body=full_message)
        except KeyboardInterrupt:
            print("\nExiting chat...")
            break

    connection.close()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python client.py <username>")
        sys.exit(1)
    
    username = sys.argv[1]
    start_client(username)
