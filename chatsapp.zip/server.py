import pika


EXCHANGE_NAME = "group_chat"

def start_server():
    connection = pika.BlockingConnection(pika.ConnectionParameters("localhost"))
    channel = connection.channel()

    channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type="fanout")

    print("[*] Server is running. Waiting for messages...")
    
    def on_message(ch, method, properties, body):
        print(f"[Broadcasting]: {body.decode()}")
        channel.basic_publish(exchange=EXCHANGE_NAME, routing_key="", body=body)

    channel.queue_declare(queue="server_queue")
    channel.basic_consume(queue="server_queue", on_message_callback=on_message, auto_ack=True)
    
    channel.start_consuming()

if __name__ == "__main__":
    start_server()
